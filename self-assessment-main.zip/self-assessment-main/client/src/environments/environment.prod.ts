export const environment = {
  production: true,
  // api_url: 'http://localhost:3000/api',
  // file_url: 'http://localhost:3000',

  // api_url: 'http://137.184.129.9/api',
  // file_url: 'http://137.184.129.9'

  api_url: 'https://stichingambassador.com/api',
  file_url: 'https://stichingambassador.com',
};
