import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-meditation-add',
  templateUrl: './meditation-add.component.html',
  styleUrls: ['./meditation-add.component.css']
})
export class MeditationAddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
