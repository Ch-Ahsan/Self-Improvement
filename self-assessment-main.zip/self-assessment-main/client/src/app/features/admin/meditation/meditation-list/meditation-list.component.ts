import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-meditation-list',
  templateUrl: './meditation-list.component.html',
  styleUrls: ['./meditation-list.component.css'],
})
export class MeditationListComponent implements OnInit {
  categoryType: any;
  service: any;
  loading = true;
  isLoading = false;

  pageSize = 20;
  collectionSize: any;
  tailors: any = [{}, {}, {}, {}, {}];

  page = 1;

  constructor() {}
  // constructor(
  // private route: ActivatedRoute,
  // private router: Router,
  // private userService: UserService
  // ) {}

  ngOnInit(): void {
    this.loading = false;
    // this.getTailors();
  }

  onPageClick(page: number) {
    this.page = page;
  }
}
