import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-meditation-detail',
  templateUrl: './meditation-detail.component.html',
  styleUrls: ['./meditation-detail.component.css']
})
export class MeditationDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
