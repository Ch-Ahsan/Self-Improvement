import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LayoutComponent } from './layout/layout.component';
import { UsersComponent } from './users/users.component';
import { UserListComponent } from './users/user-list/user-list.component';
import { UserDetailComponent } from './users/user-detail/user-detail.component';
import { MeditationComponent } from './meditation/meditation.component';
import { MeditationListComponent } from './meditation/meditation-list/meditation-list.component';
import { MeditationAddComponent } from './meditation/meditation-add/meditation-add.component';
import { MeditationDetailComponent } from './meditation/meditation-detail/meditation-detail.component';
import { BlogsListComponent } from './blogs/blogs-list/blogs-list.component';
import { BlogsAddComponent } from './blogs/blogs-add/blogs-add.component';
import { BlogDetailComponent } from './blogs/blog-detail/blog-detail.component';
import { JournalsComponent } from './journals/journals.component';
import { BooksComponent } from './books/books.component';
import { BookListComponent } from './books/book-list/book-list.component';
import { BookAddComponent } from './books/book-add/book-add.component';
import { BookDetailComponent } from './books/book-detail/book-detail.component';
import { JournalDetailComponent } from './journals/journal-detail/journal-detail.component';
import { BlogsComponent } from './blogs/blogs.component';

const routes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    children: [
      { path: '', component: DashboardComponent },
      {
        path: 'users',
        component: UsersComponent,
        children: [
          { path: '', component: UserListComponent },
          { path: 'detail/:email', component: UserDetailComponent },
        ],
      },
      {
        path: 'meditations',
        component: MeditationComponent,
        children: [
          { path: '', component: MeditationListComponent },
          { path: 'add', component: MeditationAddComponent },
          { path: 'detail/:slug', component: MeditationDetailComponent },
        ],
      },
      {
        path: 'blogs',
        component: BlogsComponent,
        children: [
          { path: '', component: BlogsListComponent },
          { path: 'add', component: BlogsAddComponent },
          { path: 'detail/:slug', component: BlogDetailComponent },
        ],
      },
      {
        path: 'books',
        component: BooksComponent,
        children: [
          { path: '', component: BookListComponent },
          { path: 'add', component: BookAddComponent },
          { path: 'detail/:slug', component: BookDetailComponent },
        ],
      },

      {
        path: 'journals',
        component: JournalsComponent,
      },
      { path: 'journals/detail/:slug', component: JournalDetailComponent },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdminRoutingModule {}
