import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/core/services';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css'],
})
export class SidebarComponent implements OnInit {
  constructor(private router: Router, private userService: UserService) {}

  ngOnInit(): void {
    this.sidebarLgCollapse();
  }

  sidebarLgCollapse() {
    const element = document.getElementsByTagName('body')[0];
    let w = element.offsetWidth;
    if (w < 992) {
      if (element.classList.contains('sidebar-xs')) {
        element.classList.remove('sidebar-xs');
      } else {
        element.classList.add('sidebar-xs');
      }
    }
  }

  logout() {
    this.userService.purgeAuth();
    this.router.navigate(['/']);
  }
}
