import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';

@Component({
  selector: 'app-journal-detail',
  templateUrl: './journal-detail.component.html',
  styleUrls: ['./journal-detail.component.css'],
})
export class JournalDetailComponent implements OnInit {
  constructor(private _location: Location) {}

  ngOnInit(): void {}

  backClicked() {
    this._location.back();
  }
}
