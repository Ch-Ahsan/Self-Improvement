import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { userStatus } from 'src/app/constants/status';
import { AdminService } from 'src/app/core/services/admin.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css'],
})
export class UserListComponent implements OnInit {
  users: any = [{}, {}, {}, {}, {}, {}, {}, {}, {}];
  selectedStatus: any;
  search = '';
  userStatusFilters = userStatus;

  constructor(private router: Router, private adminService: AdminService) {}

  ngOnInit(): void {
    // this.getUsers();
  }

  getUsers() {
    let params: any = {};

    if (this.selectedStatus) {
      params['status'] = this.selectedStatus;
    }

    if (this.search.length > 0) {
      params['search'] = this.search;
    }

    console.log('params', params);

    this.adminService.getUsers(params).subscribe((res) => {
      this.users = res.data;
      console.log('Users', res.data);
    });
  }

  changeUserStatus(status: any, email: string) {
    console.log('changeUserStatus');
    this.adminService.changeUserStatus(email, status).subscribe(
      (res: any) => {
        this.getUsers();
      },
      (err: any) => {
        console.log('err', err);
      }
    );
  }

  onStatusChange(event: any) {
    console.log('onOrderStatusChange', event);
    if (event) {
      this.selectedStatus = event.value;
    } else {
      this.selectedStatus = null;
    }
    this.getUsers();
  }
}
