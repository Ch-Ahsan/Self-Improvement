import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/core/services';
import { AdminService } from 'src/app/core/services/admin.service';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.css'],
})
export class UserDetailComponent implements OnInit {
  isLoading = false;
  tailor: any;
  email: any;

  constructor(
    private route: ActivatedRoute,
    private userService: UserService,
    private router: Router,
    private adminService: AdminService
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe((params) => {
      this.email = params['email'];
      console.log(this.email);
      this.getTailor();
    });
  }

  getTailor() {
    this.userService.getTailor(this.email).subscribe((res) => {
      this.isLoading = false;
      console.log('tailor', res);
      this.tailor = res.data;
    });
  }

  changeUserStatus(status: any, email: string) {
    console.log('changeUserStatus');
    this.adminService.changeUserStatus(email, status).subscribe(
      (res: any) => {
        this.getTailor();
      },
      (err: any) => {
        console.log('err', err);
      }
    );
  }
}
