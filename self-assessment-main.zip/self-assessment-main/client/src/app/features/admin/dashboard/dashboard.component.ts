import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/core/services/admin.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  orders: any = [];
  users: any = [];
  tailors: any = [];
  stats: any;

  constructor(private router: Router, private adminService: AdminService) {}

  ngOnInit(): void {
    this.getStats();
    this.getOrders();
    this.getUsers();
    this.getTailors();
  }

  getStats() {
    this.adminService.getStats().subscribe(
      (res) => {
        console.log(res);
        this.stats = res.data;
      },
      (err) => {
        console.log(err);
      }
    );
  }

  getOrders() {
    this.adminService.getOrders().subscribe((res) => {
      this.orders = res.data;
      console.log('Orders', res.data);
    });
  }

  getUsers() {
    this.adminService.getUsers().subscribe((res) => {
      this.users = res.data;
      console.log('Users', res.data);
    });
  }

  getTailors() {
    this.adminService.getTailors().subscribe((res) => {
      console.log('Tailors', res.data);
      this.tailors = res.data;
    });
  }
}
