import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';

@Component({
  selector: 'app-blog-detail',
  templateUrl: './blog-detail.component.html',
  styleUrls: ['./blog-detail.component.css'],
})
export class BlogDetailComponent implements OnInit {
  constructor(private _location: Location) {}

  ngOnInit(): void {}

  backClicked() {
    this._location.back();
    // this.closeModal.emit();
    // this.router.navigate(['/']);
  }
}
