import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blogs-add',
  templateUrl: './blogs-add.component.html',
  styleUrls: ['./blogs-add.component.css']
})
export class BlogsAddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
