import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blogs-list',
  templateUrl: './blogs-list.component.html',
  styleUrls: ['./blogs-list.component.css']
})
export class BlogsListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
