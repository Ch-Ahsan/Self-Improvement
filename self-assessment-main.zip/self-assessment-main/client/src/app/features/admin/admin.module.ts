import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { LayoutComponent } from './layout/layout.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import { SidebarComponent } from './layout/sidebar/sidebar.component';
import { CoreModule } from 'src/app/core/core.module';
import { UsersComponent } from './users/users.component';
import { UserDetailComponent } from './users/user-detail/user-detail.component';
import { UserListComponent } from './users/user-list/user-list.component';
import { MeditationComponent } from './meditation/meditation.component';
import { MeditationAddComponent } from './meditation/meditation-add/meditation-add.component';
import { MeditationListComponent } from './meditation/meditation-list/meditation-list.component';
import { MeditationDetailComponent } from './meditation/meditation-detail/meditation-detail.component';
import { BlogsComponent } from './blogs/blogs.component';
import { BlogsAddComponent } from './blogs/blogs-add/blogs-add.component';
import { BlogsListComponent } from './blogs/blogs-list/blogs-list.component';
import { BlogDetailComponent } from './blogs/blog-detail/blog-detail.component';
import { JournalsComponent } from './journals/journals.component';
import { BooksComponent } from './books/books.component';
import { BookAddComponent } from './books/book-add/book-add.component';
import { BookListComponent } from './books/book-list/book-list.component';
import { BookDetailComponent } from './books/book-detail/book-detail.component';
import { JournalDetailComponent } from './journals/journal-detail/journal-detail.component';

@NgModule({
  declarations: [
    LayoutComponent,
    UsersComponent,
    SidebarComponent,
    DashboardComponent,
    UserDetailComponent,
    UserListComponent,
    MeditationComponent,
    MeditationAddComponent,
    MeditationListComponent,
    MeditationDetailComponent,
    BlogsComponent,
    BlogsAddComponent,
    BlogsListComponent,
    BlogDetailComponent,
    JournalsComponent,
    BooksComponent,
    BookAddComponent,
    BookListComponent,
    BookDetailComponent,
    JournalDetailComponent,
  ],
  imports: [
    CommonModule,
    CoreModule,
    AdminRoutingModule,
    SharedModule,
    NgxDaterangepickerMd.forRoot(),
  ],
})
export class AdminModule {}
