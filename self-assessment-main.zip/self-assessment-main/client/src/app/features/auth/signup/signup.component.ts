import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/core/services';
import Swal from 'sweetalert2';
import { Location } from '@angular/common';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
})
export class SignupComponent implements OnInit {
  signupForm: any;
  hasErrors: boolean = false;
  errorMessage: string = '';
  profileImage: any = '';
  @Output() closeModal = new EventEmitter<any>();

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private userService: UserService,
    private route: ActivatedRoute,
    private _location: Location
  ) {}

  ngOnInit(): void {
    this.createForm();
  }

  createForm() {
    this.signupForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', Validators.email],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required],
    });
  }

  backClicked() {
    // this._location.back();
    this.closeModal.emit();
    this.router.navigate(['/']);
  }

  onSubmit() {
    if (this.profileImage)
      this.signupForm.value.profileImage = this.profileImage;

    console.log(this.signupForm.value);
    if (
      this.signupForm.value.password !== this.signupForm.value.confirmPassword
    ) {
      this.hasErrors = true;
      this.errorMessage = 'Password and Confirm Password does not match';
      // this.signupForm.reset();
      this.signupForm.patchValue({
        password: '',
        confirmPassword: '',
      });
    } else {
      this.userService.attemptAuth('signUp', this.signupForm.value).subscribe(
        (res) => {
          console.log(res);
          this.signupForm.reset();
          this.hasErrors = false;
          this.errorMessage = '';

          this.router.navigate([`/auth/otp/${res.data.email}/1`]);
        },
        (err) => {
          Swal.fire({
            title: 'Error!',
            text: err.message,
            icon: 'error',
            confirmButtonText: 'Go Back',
            confirmButtonColor: '#4b5c6b',
          });
        }
      );
    }
  }

  onFileUpload(event: any) {
    console.log('EVent', event);
    this.profileImage = event;
  }
}
