import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/core/services';

import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  hasErrors = false;
  errorMessage!: string;

  @Output() closeModal = new EventEmitter<any>();

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private userService: UserService
  ) {}

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      email: ['', Validators.email],
      password: ['', Validators.required],
    });
  }

  backClicked() {
    // this._location.back();
    this.closeModal.emit();
    this.router.navigate(['/']);
  }

  onSubmit() {
    console.log(this.loginForm.value);
    this.userService.attemptAuth('login', this.loginForm.value).subscribe(
      (res) => {
        console.log(res);
        this.closeModal.emit();
        if (res.data.role === 1) this.router.navigate(['/admin']);
        else this.router.navigate(['/']);
      },
      (err) => {
        this.hasErrors = true;
        if (err.status === 401) {
          Swal.fire({
            title: 'Error!',
            text: 'Not Authorized',
            icon: 'error',
            confirmButtonText: 'Go Back',
          });
        }
        if (err.code === 403) {
          this.errorMessage = 'User is not active by admin';
          Swal.fire({
            title: 'Error!',
            text: this.errorMessage,
            icon: 'error',
            confirmButtonText: 'Go Back',
          });
        } else this.errorMessage = 'Invalid credentials';
      }
    );
  }
}
