import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/core/services';
import Swal from 'sweetalert2';
import { Location } from '@angular/common';

@Component({
  selector: 'app-reset',
  templateUrl: './reset.component.html',
  styleUrls: ['./reset.component.css'],
})
export class ResetComponent implements OnInit {
  email!: string;
  passwordRestToken!: string;
  password!: string;
  confirmPassword!: string;
  resetForm: any;

  @Input() set setQueryParams(data: any) {
    console.log('----------data-----------', data);
    this.email = data.email;
    this.passwordRestToken = data.queryParams.passwordRestToken;
  }

  @Output() closeModal = new EventEmitter<any>();

  constructor(
    private router: Router,
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private _location: Location,

    private userService: UserService
  ) {}

  ngOnInit(): void {
    this.resetForm = this.fb.group({
      confirmPassword: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  backClicked() {
    // this._location.back();
    this.closeModal.emit();
    this.router.navigate(['/']);
  }

  submit() {
    if (
      this.resetForm.get('password').value ===
      this.resetForm.get('confirmPassword').value
    ) {
      this.userService
        .ResetPassword(
          this.email,
          this.resetForm.get('password').value,
          this.passwordRestToken
        )
        .subscribe(
          (res) => {
            Swal.fire({
              icon: 'success',
              title: 'Password Reset',
              showConfirmButton: false,
              timer: 1500,
            });
            this.closeModal.emit('openLogInModal');
            this.router.navigate([`/`]);
          },
          (err) => {
            Swal.fire({
              title: 'Error!',
              text: err.message,
              icon: 'error',
              confirmButtonText: 'Go Back',
            });
          }
        );
    } else {
      Swal.fire({
        title: 'Error!',
        text: 'Password and Confirm Password Not Matched',
        icon: 'error',
        confirmButtonText: 'Go Back',
        confirmButtonColor: '#4b5c6b',
      });
      return;
    }
  }
}
