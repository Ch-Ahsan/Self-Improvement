import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/core/services';
import { Location } from '@angular/common';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.css'],
})
export class ForgotComponent implements OnInit {
  email!: string;

  @Output() closeModal = new EventEmitter<any>();

  constructor(
    private userService: UserService,
    private _location: Location,

    private router: Router
  ) {}

  ngOnInit(): void {}

  backClicked() {
    // this._location.back();
    this.closeModal.emit();
    this.router.navigate(['/']);
  }

  submit() {
    this.userService.ResendOTP(this.email).subscribe(
      (res) => {
        Swal.fire({
          icon: 'success',
          title: 'OTP sent Successfully to registered email address',
          showConfirmButton: false,
          timer: 1500,
        });
        this.router.navigate(['/'], {
          queryParams: { otp: true, email: this.email, type: 2 },
        });
        // this.router.navigate([`/auth/otp/${this.email}/2`]);
        this.email = '';
      },
      (err) => {
        Swal.fire({
          title: 'Error!',
          text: err.message,
          icon: 'error',
          confirmButtonText: 'Go Back',
          confirmButtonColor: '#4b5c6b',
        });
      }
    );
  }
}
