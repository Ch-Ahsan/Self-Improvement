import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/core/services';
import Swal from 'sweetalert2';
import { Location } from '@angular/common';

@Component({
  selector: 'app-otp',
  templateUrl: './otp.component.html',
  styleUrls: ['./otp.component.css'],
})
export class OtpComponent implements OnInit {
  otp: any;
  email!: string;
  flag!: number;

  @Input() set setQueryParams(data: any) {
    console.log('----------data-----------', data);
    this.email = data.queryParams.email;
    this.flag = +data.queryParams.type;
  }

  @Output() closeModal = new EventEmitter<any>();

  constructor(
    private userService: UserService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {}

  backClicked() {
    // this._location.back();
    this.closeModal.emit();
    this.router.navigate(['/']);
  }

  onOtpChange(otp: any) {
    // console.log(otp);
    this.otp = otp;
  }

  submit() {
    // console.log('email', this.email);
    // console.log('otp', this.otp);
    console.log('flag', this.flag);

    this.userService.OTPVerify(this.email, this.otp, this.flag).subscribe(
      (res) => {
        Swal.fire({
          icon: 'success',
          title: 'Email Verified',
          showConfirmButton: false,
          timer: 1500,
        });

        if (this.flag == 1) {
          // this.router.navigate([`/auth`]);
          this.closeModal.emit('openLoginModal');
        } else if (this.flag == 2) {
          this.router.navigate([`/`], {
            queryParams: {
              passwordRestToken: res.data.passwordRestToken,
              email: this.email,
            },
          });
        } else {
          Swal.fire({
            title: 'Error!',
            text: 'Params Not Valid',
            icon: 'error',
            confirmButtonText: 'Go Back',
          });
        }
      },
      (err) => {
        Swal.fire({
          title: 'Error!',
          text: err.message,
          icon: 'error',
          confirmButtonText: 'Go Back',
          confirmButtonColor: '#4b5c6b',
        });
      }
    );
  }

  resendOTP() {
    // clear  ng otp input modal
    this.otp = '';

    // console.log('email', this.email);
    this.userService.ResendOTP(this.email).subscribe(
      (res) => {
        console.log(res);
        Swal.fire({
          icon: 'success',
          title: 'OTP sent again to registered email address',
          showConfirmButton: false,
          timer: 1500,
        });
        this.otp = '';
        // this.router.navigate([`/auth/otp/${this.email}/${this.flag}`]);
      },
      (err) => {
        Swal.fire({
          title: 'Error!',
          text: err.message,
          icon: 'error',
          confirmButtonText: 'Go Back',
        });
      }
    );
  }
}
