import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LandingRoutingModule } from './landing-routing.module';
import { LandingComponent } from './landing.component';
import { PublicNavComponent } from './layout/public-nav/public-nav.component';
import { PublicFooterComponent } from './layout/public-footer/public-footer.component';
import { PublicHomeComponent } from './public-home/public-home.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { LoginComponent } from '../auth/login/login.component';
import { SignupComponent } from '../auth/signup/signup.component';
import { OtpComponent } from '../auth/otp/otp.component';
import { ForgotComponent } from '../auth/forgot/forgot.component';
import { ResetComponent } from '../auth/reset/reset.component';

@NgModule({
  declarations: [
    LandingComponent,
    PublicNavComponent,
    PublicFooterComponent,
    PublicHomeComponent,
    LoginComponent,
    SignupComponent,
    OtpComponent,
    ForgotComponent,
    ResetComponent,
  ],
  imports: [CommonModule, LandingRoutingModule, SharedModule],
})
export class LandingModule {}
