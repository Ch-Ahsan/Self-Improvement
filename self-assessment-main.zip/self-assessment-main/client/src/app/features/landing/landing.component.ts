import { Component, OnDestroy, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css'],
})
export class LandingComponent implements OnInit, OnDestroy {
  body: any;

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.body = document.body;
    this.getRouteChanges();

    setTimeout(() => {
      document.body.classList.add('loaded');
    }, 10);
  }

  ngOnDestroy(): void {
    document.body.classList.remove('loaded');
  }

  getRouteChanges() {
    this.router.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        this.body.classList.remove('loaded');
        setTimeout(() => {
          this.body.classList.add('loaded');
        }, 1000);
      }
    });
  }
}
