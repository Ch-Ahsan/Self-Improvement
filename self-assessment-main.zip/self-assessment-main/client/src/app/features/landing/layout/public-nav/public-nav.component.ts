import {
  Component,
  ElementRef,
  HostListener,
  OnInit,
  ViewChild,
} from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { UserService } from 'src/app/core/services';

@Component({
  selector: 'app-public-nav',
  templateUrl: './public-nav.component.html',
  styleUrls: ['./public-nav.component.css'],
})
export class PublicNavComponent implements OnInit {
  public isCollapsed = true;
  closeResult!: string;
  modalBindingData: any;

  @ViewChild('logInModal', { static: true }) logInModal!: ElementRef;
  @ViewChild('signUpModal', { static: true }) signUpModal!: ElementRef;
  @ViewChild('forgetModal', { static: true }) forgetModal!: ElementRef;
  @ViewChild('otpModal', { static: true }) otpModal!: ElementRef;
  @ViewChild('resetModal', { static: true }) resetModal!: ElementRef;
  @ViewChild('nav', { static: true }) nav!: ElementRef;

  loggedIn!: boolean;
  // loggedIn: boolean = false;
  selectedTab: any = null;
  currentRoute: any = '/';

  @HostListener('window:scroll', ['$event'])
  doSomething(event: any) {
    if (this.router.url === '/') {
      if (+window?.pageYOffset > 80)
        this.nav.nativeElement.classList.remove('fixed-top');
      else this.nav.nativeElement.classList.add('fixed-top');
    }
  }

  constructor(
    private modalService: NgbModal,
    private route: ActivatedRoute,
    private userService: UserService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.userService.isAuthenticated.subscribe((data) => {
      this.loggedIn = data;
    });

    this.getDataFromUrl();
    this.getRouteChanges();

    this.currentRoute = this.router.url;
  }

  getRouteChanges() {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) this.currentRoute = event.url;
    });
  }

  getDataFromUrl() {
    // console.log('route', this.route);
    this.route.queryParams.subscribe((queryParams) => {
      console.log('queryParams', queryParams);

      // if (
      //   (queryParams['forgotPassword'] ||
      //     queryParams['verifyEmail'] ||
      //     queryParams['userBlocked'] ||
      //     queryParams['emailVerified'] ||
      //     queryParams['addUser'] ||
      //     queryParams['userNotVerified']) &&
      //   queryParams['email']
      // ) {
      //   this.getDataFromModal({ queryParams, email: queryParams['email'] });
      // }

      // if (
      //   (queryParams['resetPassword'] || queryParams['newUser']) &&
      //   queryParams['email']
      // ) {
      //   this.closeAllModals(undefined);
      //   this.open(this.resetModal);
      //   this.modalBindingData = { email: queryParams['email'] };
      // }

      // add user missing
      if (queryParams['otp'] && queryParams['email']) {
        this.closeAllModals(undefined);
        this.open(this.otpModal);
        this.modalBindingData = { email: queryParams['email'], queryParams };
      }

      if (queryParams['passwordRestToken'] && queryParams['email']) {
        this.closeAllModals('openResetModal');
        this.modalBindingData = { email: queryParams['email'], queryParams };
      }
    });
  }

  open(content: any) {
    this.modalService
      .open(content, {
        ariaLabelledBy: 'modal-basic-title',
        centered: true,
        windowClass: 'auth-modal',
      })
      .result.then(
        (result) => {
          this.closeResult = `Closed with: ${result}`;
        },
        (reason) => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  closeAllModals(e: any) {
    console.log('close all modals', e);

    this.modalService.dismissAll();

    if (e === 'openForgetModal') {
      this.open(this.forgetModal);
    } else if (e === 'openSignUpModal') {
      this.open(this.signUpModal);
    } else if (e === 'openLogInModal') {
      this.open(this.logInModal);
    } else if (e === 'openOtpModal') {
      this.open(this.otpModal);
    } else if (e === 'openResetModal') {
      this.open(this.resetModal);
    }
  }

  getDataFromModal(data: any) {
    console.log(data);
    this.closeAllModals(undefined);
    this.modalBindingData = data;
    this.open(this.otpModal);
  }

  logout() {
    this.userService.purgeAuth();
    this.router.navigate(['/']);
  }
}
