import { Component, OnInit } from '@angular/core';
import { NgbCalendar, NgbDate } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-goal-list',
  templateUrl: './goal-list.component.html',
  styleUrls: ['./goal-list.component.css'],
})
export class GoalListComponent implements OnInit {
  fromDate: NgbDate | null;
  toDate: NgbDate | null;
  selectedRange: any;
  hoveredDate: NgbDate | null = null;
  active = 1;

  constructor(private calendar: NgbCalendar) {
    this.fromDate = calendar.getToday();
    this.toDate = calendar.getNext(calendar.getToday(), 'd', 10);
  }

  ngOnInit(): void {}

  isHovered(date: NgbDate) {
    return (
      this.fromDate &&
      !this.toDate &&
      this.hoveredDate &&
      date.after(this.fromDate) &&
      date.before(this.hoveredDate)
    );
  }

  isInside(date: NgbDate) {
    return this.toDate && date.after(this.fromDate) && date.before(this.toDate);
  }

  isRange(date: NgbDate) {
    return (
      date.equals(this.fromDate) ||
      (this.toDate && date.equals(this.toDate)) ||
      this.isInside(date) ||
      this.isHovered(date)
    );
  }

  onDateSelection(date: NgbDate) {
    if (this.fromDate && this.toDate) {
      this.clearDates();
    }

    if (!this.fromDate) {
      this.fromDate = date;
    }

    if (this.fromDate && !this.toDate && date && date.after(this.fromDate)) {
      this.toDate = date;
      this.selectedRange =
        this.getDateFromObject(this.fromDate) +
        ' - ' +
        this.getDateFromObject(this.toDate);
      document.getElementById('datepickerCloser')?.click();
      let outputObject: any = {};
      outputObject['fromDate'] = this.fromDate;
      outputObject['toDate'] = this.toDate;
      outputObject['range'] = this.selectedRange;

      // this.onRangeChange.emit(outputObject);
    }

    if (this.fromDate && !this.toDate && date && !date.after(this.fromDate)) {
      // this.clearDates();
      this.fromDate = date;
    }
  }

  getDateFromObject(obj: any) {
    return `${obj.day}/${obj.month}/${obj.year}`;
  }

  clearRange() {
    // console.log('CLEAR');
    this.fromDate = null;
    this.toDate = null;
    this.selectedRange = null;
    // this.onRangeChange.emit(null);
  }

  clearDates() {
    this.fromDate = null;
    this.toDate = null;
    this.selectedRange = null;
  }
}
