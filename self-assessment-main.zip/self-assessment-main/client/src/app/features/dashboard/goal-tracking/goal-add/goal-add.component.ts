import { Component, OnInit } from '@angular/core';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { Location } from '@angular/common';

@Component({
  selector: 'app-goal-add',
  templateUrl: './goal-add.component.html',
  styleUrls: ['./goal-add.component.css'],
})
export class GoalAddComponent implements OnInit {
  model: NgbDateStruct | undefined;

  constructor(private _location: Location) {}

  ngOnInit(): void {}

  backClicked() {
    this._location.back();
  }
}
