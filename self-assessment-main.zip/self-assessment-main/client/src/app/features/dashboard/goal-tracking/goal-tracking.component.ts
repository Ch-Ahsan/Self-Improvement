import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-goal-tracking',
  templateUrl: './goal-tracking.component.html',
  styleUrls: ['./goal-tracking.component.css'],
})
export class GoalTrackingComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
