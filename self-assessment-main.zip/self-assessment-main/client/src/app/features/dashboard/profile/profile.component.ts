import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap';
import { UserService } from 'src/app/core/services';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent implements OnInit {
  profileForm!: FormGroup;
  user: any;
  isEdit = false;
  hasErrors = false;
  isImageUpLoading = false;
  errorMessage = '';

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private userService: UserService
  ) {}

  ngOnInit(): void {
    this.user = this.userService.getCurrentUser();
    console.log(this.user);

    this.createForm();
    this.patchForm();
  }

  createForm() {
    this.profileForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', Validators.email],
      profileImage: ['', Validators.required],
    });
  }

  patchForm() {
    this.profileForm.patchValue(this.user);
    // this.patchDate();
  }

  toggleEdit(bool: boolean) {
    // console.log('Profile Form', this.profileForm.value);
    if (+this.user.role === 3) {
      this.profileForm.patchValue({ webUrl: 'Not-Available', shopNum: 0 });
    }
    if (bool) this.isEdit = bool;
    else {
      this.userService.update(this.profileForm.value).subscribe(
        (res) => {
          console.log(res);
          this.hasErrors = false;
          this.errorMessage = '';
          this.profileForm.reset();
          this.isEdit = false;
          this.user = res.data;
          this.patchForm();
        },
        (err) => {
          console.log(err);
          this.hasErrors = true;
          this.errorMessage = err.message;
        }
      );
    }
  }

  onFileUpload(event: any) {
    console.log('EVENT', event);
    this.profileForm.patchValue({ profileImage: event });
    this.user.profileImage = event;
  }

  toggleUpLoading(event: any) {
    this.isImageUpLoading = event;
  }
}
