import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-journal',
  templateUrl: './add-journal.component.html',
  styleUrls: ['./add-journal.component.css']
})
export class AddJournalComponent implements OnInit {

  constructor() { }

  cars = [
      { id: 1, name: 'Private' },
      { id: 2, name: 'Public' },
  ];


  ngOnInit(): void {
  }

}
