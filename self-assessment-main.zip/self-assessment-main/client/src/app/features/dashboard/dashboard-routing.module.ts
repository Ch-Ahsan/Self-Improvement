import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PublicHomeComponent } from '../landing/public-home/public-home.component';
import { BlogDetailComponent } from './blog/blog-detail/blog-detail.component';
import { BlogComponent } from './blog/blog.component';
import { BookRecommendationComponent } from './book-recommendation/book-recommendation.component';
import { GoalAddComponent } from './goal-tracking/goal-add/goal-add.component';
import { GoalDetailComponent } from './goal-tracking/goal-detail/goal-detail.component';
import { GoalListComponent } from './goal-tracking/goal-list/goal-list.component';
import { GoalTrackingComponent } from './goal-tracking/goal-tracking.component';
import { AddJournalComponent } from './journal/add-journal/add-journal.component';
import { JournalDetailComponent } from './journal/journal-detail/journal-detail.component';
import { JournalListComponent } from './journal/journal-list/journal-list.component';
import { JournalComponent } from './journal/journal.component';
import { MeditationDetailComponent } from './meditation/meditation-detail/meditation-detail.component';
import { MeditationListComponent } from './meditation/meditation-list/meditation-list.component';
import { MeditationComponent } from './meditation/meditation.component';
import { ProfileComponent } from './profile/profile.component';

const routes: Routes = [
  {
    path: '',
    component: PublicHomeComponent,
  },
  {
    path: 'meditation',
    component: MeditationComponent,
    children: [
      {
        path: '',
        component: MeditationListComponent,
      },

      {
        path: 'detail/:slug',
        component: MeditationDetailComponent,
      },
    ],
  },
  {
    path: 'journal',
    component: JournalComponent,
    children: [
      {
        path: '',
        component: JournalListComponent,
      },
      {
        path: 'add',
        component: AddJournalComponent,
      },
      {
        path: 'detail/:slug',
        component: JournalDetailComponent,
      },
    ],
  },

  {
    path: 'goal-tracking',
    component: GoalTrackingComponent,
    children: [
      {
        path: '',
        component: GoalListComponent,
      },
      {
        path: 'add',
        component: GoalAddComponent,
      },
      {
        path: 'detail/:slug',
        component: GoalDetailComponent,
      },
    ],
  },

  {
    path: 'book-recommendations',
    component: BookRecommendationComponent,
  },
  {
    path: 'blogs',
    component: BlogComponent,
  },
  {
    path: 'blogs/detail',
    component: BlogDetailComponent,
  },

  {
    path: 'profile',
    component: ProfileComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DashboardRoutingModule {}
