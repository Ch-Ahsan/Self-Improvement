import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-book-recommendation',
  templateUrl: './book-recommendation.component.html',
  styleUrls: ['./book-recommendation.component.css'],
})
export class BookRecommendationComponent implements OnInit {
  closeResult: string | undefined;

  constructor(private modalService: NgbModal) {}
  active = 1;

  ngOnInit(): void {}
  selectedCar: number | undefined;

  cars = [
      { id: 1, name: 'Volvo' },
      { id: 2, name: 'Saab' },
      { id: 3, name: 'Opel' },
      { id: 4, name: 'Audi' },
  ];

  open(content: any) {
    this.modalService
      .open(content, { ariaLabelledBy: 'modal-basic-title',  centered: true })
      .result.then(
        (result: any) => {
          this.closeResult = `Closed with: ${result}`;
        },
        (reason: any) => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  getDismissReason(reason: any) {
    throw new Error('Method not implemented.');
  }
}
