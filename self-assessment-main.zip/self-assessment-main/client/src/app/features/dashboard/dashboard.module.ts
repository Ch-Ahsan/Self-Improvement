import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { ProfileComponent } from './profile/profile.component';
// import { WeekDaySelectorModule } from 'week-day-selector';
import { JournalComponent } from './journal/journal.component';
import { JournalListComponent } from './journal/journal-list/journal-list.component';
import { AddJournalComponent } from './journal/add-journal/add-journal.component';
import { JournalDetailComponent } from './journal/journal-detail/journal-detail.component';
import { BookRecommendationComponent } from './book-recommendation/book-recommendation.component';
import { BlogComponent } from './blog/blog.component';
import { GoalTrackingComponent } from './goal-tracking/goal-tracking.component';
import { GoalListComponent } from './goal-tracking/goal-list/goal-list.component';
import { GoalAddComponent } from './goal-tracking/goal-add/goal-add.component';
import { GoalDetailComponent } from './goal-tracking/goal-detail/goal-detail.component';
import { MeditationComponent } from './meditation/meditation.component';
import { MeditationDetailComponent } from './meditation/meditation-detail/meditation-detail.component';
import { MeditationListComponent } from './meditation/meditation-list/meditation-list.component';
import { BlogDetailComponent } from './blog/blog-detail/blog-detail.component';

@NgModule({
  declarations: [
    DashboardComponent,
    ProfileComponent,
    JournalComponent,
    JournalListComponent,
    AddJournalComponent,
    JournalDetailComponent,
    BookRecommendationComponent,
    BlogComponent,
    GoalTrackingComponent,
    GoalListComponent,
    GoalAddComponent,
    GoalDetailComponent,
    MeditationComponent,
    MeditationDetailComponent,
    MeditationListComponent,
    BlogDetailComponent,
  ],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    SharedModule,
    // WeekDaySelectorModule,
  ],
})
export class DashboardModule {}
