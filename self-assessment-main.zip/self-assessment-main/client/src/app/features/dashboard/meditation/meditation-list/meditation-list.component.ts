import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-meditation-list',
  templateUrl: './meditation-list.component.html',
  styleUrls: ['./meditation-list.component.css'],
})
export class MeditationListComponent implements OnInit {
  categoryType: any;
  service: any;
  loading = true;
  isLoading = false;

  pageSize = 20;
  collectionSize: any;
  tailors: any = [{}, {}, {}, {}, {}];

  page = 1;

  constructor() {}
  // constructor(
  // private route: ActivatedRoute,
  // private router: Router,
  // private userService: UserService
  // ) {}

  ngOnInit(): void {
    this.loading = false;
    // this.getTailors();
  }

  onPageClick(page: number) {
    this.page = page;
  }

  // getTailors() {
  //   let params = { page: this.page, pageSize: this.pageSize };
  //   this.userService.getTailors(params).subscribe((res: any) => {
  //     this.isLoading = false;
  //     console.log('tailors', res);
  //     this.tailors = res.data.docs;
  //     this.collectionSize = res.data.totalDocs;
  //     this.page = res.data.page;
  //   });
  // }
}
