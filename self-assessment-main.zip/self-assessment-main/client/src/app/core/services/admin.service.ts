import { Injectable } from '@angular/core';
import { ApiService } from '.';

@Injectable({
  providedIn: 'root',
})
export class AdminService {
  constructor(private apiService: ApiService) {}

  getStats() {
    return this.apiService.get('/admin/stats');
  }

  getOrders(params: any = {}) {
    return this.apiService.get(`/admin/get/orders`, params);
  }

  getTailors(params: any = {}) {
    return this.apiService.get(`/admin/get/tailors`, params);
  }

  getUsers(params: any = {}) {
    return this.apiService.get(`/admin/get/users`, params);
  }

  getComplaints() {
    return this.apiService.get(`/admin/get/complaints`);
  }

  changeUserStatus(email: string, status: any) {
    return this.apiService.put(`/admin/change/status/${email}`, { status });
  }
}
