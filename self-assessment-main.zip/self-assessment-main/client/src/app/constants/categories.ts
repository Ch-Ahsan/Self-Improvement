export const Categories = [
  { value: 1, name: 'Churi Dar' },
  { value: 2, name: 'Frock' },
  { value: 3, name: 'Kurti' },
  { value: 4, name: 'Night Gown' },
  { value: 5, name: 'Pants' },
  { value: 6, name: 'Shalwar Qameez' },
  { value: 7, name: 'Shirts' },
  { value: 8, name: 'Shorts' },
];
