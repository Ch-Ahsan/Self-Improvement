export const userStatus = [
  { value: 1, name: 'Active' },
  { value: 2, name: 'Blocked' },
  // { value: 3, name: 'Pending' },
];

export const orderStatus = [
  { value: 1, name: 'In Progress' },
  { value: 2, name: 'Completed' },
  { value: 3, name: 'Cancelled' },
];
