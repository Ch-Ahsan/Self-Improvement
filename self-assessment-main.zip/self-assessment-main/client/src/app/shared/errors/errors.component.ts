import { Component, OnInit, Input } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'errors',
  templateUrl: './errors.component.html',
  styleUrls: ['./errors.component.css'],
})
export class ErrorsComponent implements OnInit {
  // @Input() control: any;
  // @Input() isSubmit: any = false;

  control: any;

  constructor() {}

  ngOnInit(): void {}

  setControl(control: any): void {
    // console.log('setControl', this.control);
    this.control = control;
  }
}
