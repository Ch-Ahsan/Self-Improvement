import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'gender',
})
export class GenderPipe implements PipeTransform {
  transform(gender: number): any {
    if (gender === 1) return 'Male';
    else if (gender === 2) return 'Female';
    else return 'Other';
  }
}
