import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'city',
})
export class CityPipe implements PipeTransform {
  transform(city: number): string {
    if (city === 1) return 'Gujranwala';
    else if (city === 2) return 'Gujarat';
    else if (city === 3) return 'Lahore';
    else if (city === 4) return 'Karachi';
    else return '';
  }
}
