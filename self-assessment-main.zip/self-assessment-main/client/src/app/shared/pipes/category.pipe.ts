import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'category',
})
export class CategoryPipe implements PipeTransform {
  transform(category: number): string {
    if (category === 1) return 'Churidaar';
    else if (category === 2) return 'Frock';
    else if (category === 3) return 'Kurti';
    else if (category === 4) return 'Night Gown';
    else if (category === 5) return 'Pants';
    else if (category === 6) return 'Shalwar Qameez';
    else if (category === 7) return 'Shirt';
    else if (category === 8) return 'Shorts';
    else return '';
  }
}
