import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'orderStatus',
})
export class OrderStatusPipe implements PipeTransform {
  transform(status: number): string {
    if (status === 1) return 'In Progress';
    else if (status === 2) return 'Completed';
    else if (status === 3) return 'Cancelled';
    else return '';
  }
}
