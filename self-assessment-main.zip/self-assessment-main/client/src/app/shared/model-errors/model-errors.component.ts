import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-model-errors',
  templateUrl: './model-errors.component.html',
  styleUrls: ['./model-errors.component.css'],
})
export class ModelErrorsComponent implements OnInit {
  @Input() isRequired: boolean = false;
  @Input() isEmail: boolean = false;
  @Input() isMinLength: number = 0;
  @Input() isMaxLength: number = 0;
  @Input() isPattern: boolean = false;
  @Input() isCustomTime: boolean = false;
  @Input() isConfirmPasswordValidator: boolean = false;
  @Input() hasCapitalCase: boolean = false;
  @Input() hasSmallCase: boolean = false;
  @Input() hasNumber: boolean = false;
  @Input() expression: string = '';

  @Output() err = new EventEmitter<any>();

  errors: any = [];

  constructor() {}

  ngOnInit(): void {}

  setControl(control: any): void {
    // console.log('setControl', this.control);
    console.log('----------control-----------', control);
    this.errors = [];

    // this.control = control;

    if (this.isRequired) {
      if (control.value === '' || control.value === null || !control.value) {
        this.errors.push('This field is required');
        this.err.emit('This field is required');
      }
    }

    // if (control) {
    // if (this.isRequired) {
    //   if (control.length <= 0) this.errors.push('Field is required');
    // }
    if (this.isEmail) {
      const re =
        /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      if (!re.test(control.value)) this.errors.push('Email is invalid');
    }
    if (this.isMinLength > 0) {
      if (control.value?.length < this.isMinLength)
        this.errors.push(
          'Field must be at least ' + this.isMinLength + ' characters'
        );
      this.err.emit(
        'Field must be at least ' + this.isMinLength + ' characters'
      );
    }
    if (this.isMaxLength > 0) {
      if (control.value?.length > this.isMaxLength)
        this.errors.push(
          'Field must be less than ' + this.isMaxLength + ' characters'
        );
      this.err.emit(
        'Field must be less than ' + this.isMaxLength + ' characters'
      );
    }
    if (this.isPattern) {
      const re = new RegExp(this.expression);
      if (!re.test(control.value)) {
        this.errors.push('Field is invalid');
        this.err.emit('Field is invalid');
      }
    }
    if (this.isConfirmPasswordValidator) {
      if (control.value !== this.expression) {
        this.errors.push('Passwords do not match');
        this.err.emit('Passwords do not match');
      }
    }

    if (this.hasCapitalCase) {
      const re = /[A-Z]/;
      if (!re.test(control.value))
        this.errors.push('Field must have capital letter');
      this.err.emit('Field must have capital letter');
    }

    if (this.hasSmallCase) {
      const re = /[a-z]/;
      if (!re.test(control.value))
        this.errors.push('Field must have small letter');
      this.err.emit('Field must have small letter');
    }

    if (this.hasNumber) {
      const re = /[0-9]/;
      if (!re.test(control.value)) {
        this.errors.push('Field must have number');
        this.err.emit('Field must have number');
      }
    }

    if (this.isCustomTime) {
      // const re = /^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/;
      // if (!re.test(control.value)) {
      //   this.errors.push('Field must be a valid time');
      //   this.err.emit('Field must be a valid time');
      // }

      // check it contain am or pm|| AM or PM || Am or Pm || aM or pM
      // const re = /^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9] (am|pm|AM|PM|Am|Pm)$/;
      // // const re = /^* (am|pm|AM|PM|Am|Pm)$/;
      // if (!re.test(control.value)) {
      //   this.errors.push('Field must be a valid time');
      //   this.err.emit('Field must be a valid time');
      // }

      console.log(control.value);
      console.log(!control.value.toLowerCase().includes('am'));
      console.log(!control.value.toLowerCase().includes('pm'));

      if (
        !control.value.toLowerCase().includes('am') ||
        !control.value.toLowerCase().includes('pm')
      ) {
        this.errors.push('Field must be a valid time');
        this.err.emit('Field must be a valid time');
      }
    }

    // }
  }
}
