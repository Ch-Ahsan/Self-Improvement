import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { FileItem, FileUploader } from 'ng2-file-upload';
import { environment } from 'src/environments/environment';
import Swal from 'sweetalert2';

function readBase64(file: any): Promise<any> {
  var reader = new FileReader();
  var future = new Promise((resolve, reject) => {
    reader.addEventListener(
      'load',
      function () {
        resolve(reader.result);
      },
      false
    );

    reader.addEventListener(
      'error',
      function (event) {
        reject(event);
      },
      false
    );

    reader.readAsDataURL(file);
  });
  return future;
}

@Component({
  selector: 'app-uploader',
  templateUrl: './uploader.component.html',
  styleUrls: ['./uploader.component.css'],
})
export class UploaderComponent implements OnInit {
  uploader: FileUploader = new FileUploader({
    url: `${environment.file_url}/api/upload`,
  });

  @ViewChild('input') input!: ElementRef;
  @Input() multiple = true;
  @Input() single = true;
  @Input() image = false;
  @Input() file = false;

  @Input() accept = 'image/png, image/jpeg,application/pdf';
  @Output() output = new EventEmitter<any>();
  // 1- return image url after uploading file
  //2- return base64 String URL and not upload the file in uploads folder
  //3- return file object
  @Input() outputType: any = [1, 2, 3];
  imgView = '';
  base64textString: any;
  fileName: any;
  fileExtension: any;
  fileToBeUploaded: any;
  fileObject!: File;
  constructor() {}

  ngOnInit() {}

  click() {
    this.input.nativeElement.click();
  }
  onImageSelect(event: any) {
    this.fileObject = event;
    // this.onFileChange(event);
    this.fileName = event.target.files[0].name;
    let fileExtension = event.target.files[0].name.split('.').pop();
    if (
      fileExtension !== 'jpeg' &&
      fileExtension !== 'jpg' &&
      fileExtension !== 'png'
    ) {
      Swal.fire('Only JPG, JPEG and PNG files are supported', '', 'error');
      return;
    }
    // fileNameWithExtension.split('[.]', 0);

    // this.fileToBase64(event);
    this.fileToFileItem(event);
  }

  resetEvent(event: any) {
    event.target.value = null;
  }

  onFileSelect(event: any) {
    // console.log(event.target.files);
    const _file = event.target.files[0];
    const name = _file.name.split('.');
    const fileExtension = name[name.length - 1];
    // console.log(fileExtension);
    //allows only image png, jpeg, jpg

    //allows only image png, jpeg, jpg, pdf

    if (
      fileExtension !== 'pdf' &&
      fileExtension !== 'jpg' &&
      fileExtension !== 'jpeg' &&
      fileExtension !== 'png'
    ) {
      Swal.fire('Only PDF, JPG and PNG files are supported', '', 'error');
      return;
    }

    const reader = new FileReader();
    reader.readAsDataURL(_file);
    reader.onload = async () => {
      let file = new File([this.dataURItoBlob(reader.result)], _file.name, {
        type: fileExtension,
      });
      this.fileToBeUploaded = new FileItem(this.uploader, file, {});

      this.uploader.queue.push(this.fileToBeUploaded);
      this.fileToBeUploaded.upload();
      this.uploader.onErrorItem = (item, response, status, headers) => {};
      this.uploader.onSuccessItem = (item, response, status, headers) => {
        // console.log(response);
        // console.log(JSON.parse(response).url);
        const file = {
          fileName: _file.name,
          fileAddress: environment.file_url + '/' + JSON.parse(response).url,
        };
        this.output.emit(file);
      };
    };
  }
  upload() {
    this.uploader.queue.push(this.fileToBeUploaded);
    this.fileToBeUploaded.upload();
    this.uploader.onErrorItem = (item, response, status, headers) => {};
    this.uploader.onSuccessItem = (item, response, status, headers) => {
      this.output.emit(JSON.parse(response).url);
      this.imgView = JSON.parse(response).url;
    };
  }

  dataURItoBlob(dataURI: any): Blob {
    const byteString = atob(dataURI.split(',')[1]);
    const mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
    const ab = new ArrayBuffer(byteString.length);
    let ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    return new Blob([ab], { type: 'image/jpg' });
  }

  fileToBase64(event: any) {
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = async () => {
      this.base64textString = await reader.result;
      return reader.result;
    };
  }
  fileToFileItem(event: any) {
    const _file = event.target.files[0];
    const reader = new FileReader();
    reader.readAsDataURL(_file);
    reader.onload = async () => {
      this.base64textString = await reader.result;
      let file = new File([this.dataURItoBlob(reader.result)], this.fileName, {
        type: 'image/jpg',
      });
      this.fileToBeUploaded = new FileItem(this.uploader, file, {});

      this.uploader.queue.push(this.fileToBeUploaded);
      this.fileToBeUploaded.upload();
      this.uploader.onErrorItem = (item, response, status, headers) => {};
      this.uploader.onSuccessItem = (item, response, status, headers) => {
        // console.log(response);
        // console.log(JSON.parse(response).url);
        this.output.emit(environment.file_url + '/' + JSON.parse(response).url);
        this.imgView = environment.file_url + '/' + JSON.parse(response).url;
      };
    };
  }
}
