import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NgOtpInputModule } from 'ng-otp-input';
import { NgSelectModule } from '@ng-select/ng-select';
import { HttpClientModule } from '@angular/common/http';
import { StatusPipe } from './pipes/status.pipe';
import { LoaderComponent } from './loader/loader.component';
import { FileUploadModule } from 'ng2-file-upload';
import { OrderStatusPipe } from './pipes/order-status.pipe';
import { CategoryPipe } from './pipes/category.pipe';
import { GenderPipe } from './pipes/gender.pipe';
import { NumericOnlyDirective } from './directives/numeric.directive';
import { CityPipe } from './pipes/city.pipe';
import { ErrorsComponent } from './errors/errors.component';
import { ModelErrorsComponent } from './model-errors/model-errors.component';
import { UploaderComponent } from './uploader/uploader.component';

const SHARED_PIPES = [
  OrderStatusPipe,
  StatusPipe,
  CategoryPipe,
  GenderPipe,
  CityPipe,
];

const SHARED_COMPONENTS = [
  LoaderComponent,
  UploaderComponent,
  ErrorsComponent,
  ModelErrorsComponent,
];

const SHARED_MODULES = [NgOtpInputModule, FileUploadModule, NgSelectModule];

const SHARED_DIRECTIVES = [NumericOnlyDirective];

@NgModule({
  declarations: [SHARED_PIPES, SHARED_COMPONENTS, SHARED_DIRECTIVES],
  imports: [
    CommonModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule,
    SHARED_MODULES,
  ],
  exports: [
    CommonModule,
    NgbModule,
    FormsModule,
    RouterModule,
    ReactiveFormsModule,
    HttpClientModule,
    SHARED_PIPES,
    SHARED_COMPONENTS,
    SHARED_MODULES,
    SHARED_DIRECTIVES,
  ],
})
export class SharedModule {}
