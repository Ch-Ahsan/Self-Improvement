let { BadRequestResponse, UnauthorizedResponse, ForbiddenResponse } = require("express-http-response");

function changeDateFormat(date) {
	console.log("Changing date format", date);
	let year = date.year;
	let month = date.month <= 9 ? "0" + date.month : date.month;
	let day = date.day <= 9 ? "0" + date.day : date.day;
	console.log(year, month, day);
	console.log(year + "-" + month + "-" + day);
	return year + "-" + month + "-" + day;
}

module.exports = { changeDateFormat };
