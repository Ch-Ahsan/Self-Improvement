"use strict";
module.exports = {
	// backend: "http://137.184.129.9/",
	// frontend: "http://137.184.129.9/",
	backend: "https://stichingambassador.com",
	frontend: "https://stichingambassador.com",
	// backend: "http://localhost:3000",
	// frontend: "http://localhost:4200",
	PORT: 3000,
	MONGODB_URI: "mongodb://localhost:27017/assessment",
	secret: "secret",
	host: "",
	smtpAuth: {
		user: "admin@deomgevingsverbinder.nl",
		pass: "Olifant1234!",
	},
	allowedOrigins: ["http://localhost:4200", "http://localhost:4300", "http://localhost:3000"],
};
