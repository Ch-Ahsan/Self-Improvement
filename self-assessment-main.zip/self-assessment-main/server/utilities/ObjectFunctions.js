function removeUnChangedControls(objFrom, objBy) {
	for (let key in objFrom) {
		if (objFrom[key] === objBy[key]) delete objFrom[key];
	}

	return objFrom;
}
function replaceChangedControls(objFrom, objBy) {
	for (let key in objBy) {
		if (objFrom[key] !== objBy[key]) objFrom[key] = objBy[key];
	}

	return objFrom;
}

module.exports = { removeUnChangedControls, replaceChangedControls };
