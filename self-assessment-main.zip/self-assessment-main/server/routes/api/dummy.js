let router = require("express").Router();
let User = require("../../models/User");
let Dummy = require("../../models/Dummy");
let auth = require("../auth");
let { OkResponse, BadRequestResponse, UnauthorizedResponse } = require("express-http-response");
const { query } = require("express");
const { removeUnChangedControls, replaceChangedControls } = require("../../utilities/ObjectFunctions");

router.param("slug", (req, res, next, slug) => {
	Dummy.findOne({ slug }, (err, dummy) => {
		if (err) return next(new BadRequestResponse(err));
		else if (!dummy) return next(new BadRequestResponse("dummy not found"));
		req.dummy = dummy;
		next();
	});
});

// REST API's
// router.post("/add", auth.required, auth.user, (req, res, next) => {
router.post("/", auth.required, auth.user, (req, res, next) => {
	console.log(req.body);
	if (!req.body.email || !req.body.name || !req.body.age)
		return next(new BadRequestResponse("Missing required fields"));
	else if (req.body.email.length <= 0 || req.body.name.length <= 0 || req.body.age.length <= 0) {
		return next(new BadRequestResponse("Missing required fields"));
	}

	let dummy = new Dummy();

	dummy.email = req.body.email;
	dummy.name = req.body.name;
	dummy.age = req.body.age;
	dummy.createdBy = req.user._id;
	dummy.save((err, dummy) => {
		if (err) return next(new BadRequestResponse(err));
		return next(new OkResponse(dummy));
	});
});
// router.get("/getAll", auth.required, auth.user, (req, res, next) => {
router.get("/", auth.required, auth.user, (req, res, next) => {
	let options = {
		sort: {
			createdAt: -1,
		},
	};

	let query = {};
	query.createdBy = req.user._id;

	Dummy.find(query, null, options, (err, dummy) => {
		if (err) return next(new BadRequestResponse(err));
		return next(new OkResponse(dummy));
	});
});

// router.get("/get/:slug", auth.required, auth.user, (req, res, next) => {
router.get("/:slug", auth.required, auth.user, (req, res, next) => {
	return next(new OkResponse(req.dummy));
});

// router.put("/update/:slug", auth.required, auth.user, (req, res, next) => {
router.put("/:slug", auth.required, auth.user, (req, res, next) => {
	if (req.body.email) req.dummy.email = req.body.email || req.dummy.email;
	if (req.body.name) req.dummy.name = req.body.name || req.dummy.name;
	if (req.body.age) req.dummy.age = req.body.age || req.dummy.age;

	req.dummy.save((err, dummy) => {
		if (err) return next(new BadRequestResponse(err));
		return next(new OkResponse(dummy));
	});
});

// router.delete("/del/:slug", auth.required, auth.user, (req, res, next) => {
router.delete("/:slug", auth.required, auth.user, (req, res, next) => {
	req.dummy.remove((err, dummy) => {
		if (err) return next(new BadRequestResponse(err));
		return next(new OkResponse(dummy));
	});
});

module.exports = router;
