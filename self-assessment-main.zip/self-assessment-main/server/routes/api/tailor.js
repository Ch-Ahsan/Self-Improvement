let router = require("express").Router();

let { OkResponse, BadRequestResponse } = require("express-http-response");

const User = require("../../models/User");
const Order = require("../../models/Order");

const auth = require("../auth");

// get user for every time mail given
router.param("email", (req, res, next, email) => {
	User.findOne({ email }, (err, user) => {
		if (!err && user !== null) {
			// console.log(user);
			req.userToUpdate = user;
			return next();
		}
		return next(new BadRequestResponse("User not found!", 423));
	});
});

// Get Tailor Stats
router.get("/get/stats", auth.required, auth.tailor, (req, res, next) => {
	Order.find({ tailor: req.user._id }, async (err, orders) => {
		if (err) return next(new BadRequestResponse(err));
		if (!orders)
			return next(
				new OkResponse({
					orders: 0,
					pendingOrders: 0,
					completedOrders: 0,
					cancelledOrders: 0,
					clients: 0,
					activeClients: 0,
					blockedClients: 0,
				})
			);
		// console.log("ORDERSSS", orders);

		let clients = [];
		let clientSet = new Set();
		orders.forEach((order) => {
			clientSet.add(order.user);
		});
		clients = [...clientSet];

		try {
			let pendingOrders = await Order.countDocuments({ tailor: req.user, status: 1 });
			let completedOrders = await Order.countDocuments({ tailor: req.user, status: 2 });
			let cancelledOrders = await Order.countDocuments({ tailor: req.user, status: 3 });

			let activeClients = clients.filter((client) => client.status === 1).length;
			let blockedClients = clients.filter((client) => client.status === 2).length;

			return next(
				new OkResponse({
					orders: orders.length,
					pendingOrders,
					completedOrders,
					cancelledOrders,
					clients: clients.length,
					activeClients,
					blockedClients,
				})
			);
		} catch (error) {
			return next(new BadRequestResponse(error));
		}
	});
});

// View All tailors
router.get("/getAll", auth.required, auth.user, (req, res, next) => {
	// console.log("Inside");
	const options = {
		page: +req.query.page || 1,
		limit: +req.query.limit || 20,
		sort: { createdAt: -1 },
	};

	let query = {};
	query.role = 2;

	console.log(query);

	User.paginate(query, options, (err, result) => {
		if (err) return next(new BadRequestResponse(err), 500);
		console.log(result);
		return next(new OkResponse(result));
	});
});

// View All Clients
router.get("/get/clients", auth.required, auth.tailor, (req, res, next) => {
	// console.log("Inside");
	const options = {
		page: +req.query.page || 1,
		limit: +req.query.limit || 20,
		sort: { createdAt: -1 },
	};

	let query = {};
	query.role = 3;

	User.paginate(query, options, (err, result) => {
		if (err) return next(new BadRequestResponse(err), 500);
		console.log(result);
		return next(new OkResponse(result));
	});
});

// View Specific Tailor
router.get("/get/:email", auth.required, auth.user, (req, res, next) => {
	return next(new OkResponse(req.userToUpdate));
});

// Update Specific Tailor
router.put("/edit/signUp/:email", (req, res, next) => {
	console.log(req.body);
	req.userToUpdate.webUrl = req.body.webUrl || req.userToUpdate.webUrl;
	req.userToUpdate.shopNum = req.body.shopNumber || req.userToUpdate.shopNum;
	req.userToUpdate.role = 2;
	req.userToUpdate.save((err, user) => {
		if (err) return next(new BadRequestResponse(err));
		return next(new OkResponse(user));
	});
});

module.exports = router;
