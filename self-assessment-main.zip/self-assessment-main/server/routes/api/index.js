let router = require("express").Router();

router.use("/users", require("./users"));
router.use("/tailor", require("./tailor"));
router.use("/order", require("./order"));
router.use("/admin", require("./admin"));
router.use("/requirement", require("./requirement"));
router.use("/complaint", require("./complaint"));
router.use("/dummy", require("./dummy"));

router.use("/public", require("./public"));
router.use("/upload", require("./upload"));

module.exports = router;
