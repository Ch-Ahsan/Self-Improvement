let router = require("express").Router();
let User = require("../../models/User");
let Complaint = require("../../models/Complaint");
let Requirement = require("../../models/Requirement");
let auth = require("../auth");
let { OkResponse, BadRequestResponse, UnauthorizedResponse } = require("express-http-response");
const { query } = require("express");
const { removeUnChangedControls, replaceChangedControls } = require("../../utilities/ObjectFunctions");

router.param("slug", (req, res, next, slug) => {
	Complaint.findOne({ slug }, (err, complaint) => {
		if (err) return next(new BadRequestResponse(err));
		else if (!complaint) return next(new BadRequestResponse("Complaint not found"));
		req.complaint = complaint;
		next();
	});
});

router.post("/add", auth.required, auth.user, (req, res, next) => {
	console.log(req.body);

	let complaint = new Complaint(req.body);

	complaint.by = req.user._id;

	console.log(complaint);

	complaint.save((err, complaint) => {
		if (err) return next(new BadRequestResponse(err));
		return next(new OkResponse(complaint));
	});
});

// View Specific Order Requirements
router.get("/getAll", auth.required, auth.user, (req, res, next) => {
	let query = { by: req.user._id };
	Complaint.find(query, (err, complaints) => {
		if (err) return next(new BadRequestResponse(err));
		console.log("found complaints", complaints);
		return next(new OkResponse(complaints));
	});
});
// View Specific Order Requirements
router.get("/get/:order", auth.required, auth.user, (req, res, next) => {
	console.log("Inside", req.order);
	let query = { order: req.order._id };
	Requirement.findOne(query, (err, requirement) => {
		if (err) return next(new BadRequestResponse(err));
		console.log("found requirement", requirement);
		return next(new OkResponse(requirement));
	});
});

router.post("/edit/:order", auth.required, auth.user, (req, res, next) => {
	console.log(req.body.requirements);

	if (req.order.user._id.toString() === req.user._id.toString()) {
		let query = { order: req.order._id };

		Requirement.findOne(query, (err, requirementToUpdate) => {
			if (err) return next(new BadRequestResponse(err));
			console.log("found requirement", requirementToUpdate);
			let distinctRequirements = removeUnChangedControls(req.body.requirements, requirementToUpdate);
			// requirementToUpdate = req.body.requirements;

			console.log("found distinct requirements-------", distinctRequirements);

			if (Object.keys(distinctRequirements).length > 0) {
				let updatedRequirements = replaceChangedControls(requirementToUpdate, distinctRequirements);

				console.log("Updated requirements-------", updatedRequirements);

				updatedRequirements.save((err, requirement) => {
					if (err) return next(new BadRequestResponse(err));
					return next(new OkResponse(requirement));
				});
			} else return next(new OkResponse(requirementToUpdate));
		});
	} else return next(new BadRequestResponse("You are not authorized to edit this order"));
});

module.exports = router;
