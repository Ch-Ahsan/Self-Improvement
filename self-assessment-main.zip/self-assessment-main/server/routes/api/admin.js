let router = require("express").Router();
let User = require("../../models/User");
let Order = require("../../models/Order");
let Complaint = require("../../models/Complaint");
let auth = require("../auth");
let { OkResponse, BadRequestResponse, UnauthorizedResponse } = require("express-http-response");

router.param("email", (req, res, next, email) => {
	User.findOne({ email }, (err, user) => {
		if (!err && user !== null) {
			// console.log(user);
			req.userToUpdate = user;
			return next();
		}
		return next(new BadRequestResponse("User not found!", 423));
	});
});

router.param("order", (req, res, next, slug) => {
	Order.findOne({ slug }, (err, order) => {
		if (err) return next(new BadRequestResponse(err));
		if (!order) return next(new BadRequestResponse("Order not Found"));
		req.orderToUpdate = order;
		next();
	});
});

router.get("/stats", auth.required, auth.admin, async (req, res, next) => {
	try {
		let orders = await Order.countDocuments();
		let tailors = await User.countDocuments({ role: 2 });
		let users = await User.countDocuments({ role: 3 });
		return next(
			new OkResponse({
				orders,
				tailors,
				users,
			})
		);
	} catch (error) {
		return next(new BadRequestResponse(error));
	}
});

router.get("/get/users", auth.required, auth.admin, (req, res, next) => {
	const options = {
		// page: +req.query.page || 1,
		// limit: +req.query.limit || 10,
		sort: { createdAt: -1 },
	};

	let query = {};
	if (req.query.status) query.status = +req.query.status;
	if (req.query.search) query.name = { $regex: req.query.search, $options: "i" };

	query.role = 3;

	User.find(query, null, options, (err, users) => {
		if (err) return next(new BadRequestResponse(err));
		if (!users) return next(new OkResponse([]));
		console.log("users", users);
		return next(new OkResponse(users));
	});
});

router.get("/get/tailors", auth.required, auth.admin, (req, res, next) => {
	const options = {
		// page: +req.query.page || 1,
		// limit: +req.query.limit || 10,
		sort: { createdAt: -1 },
	};

	let query = {};
	if (req.query.status) query.status = +req.query.status;
	if (req.query.search) query.name = { $regex: req.query.search, $options: "i" };

	query.role = 2;

	User.find(query, null, options, (err, tailors) => {
		if (err) return next(new BadRequestResponse(err));
		if (!tailors) return next(new OkResponse([]));
		console.log("tailors", tailors);
		return next(new OkResponse(tailors));
	});
});

router.get("/get/orders", auth.required, auth.admin, (req, res, next) => {
	console.log("req.query", req.query);
	const options = {
		// page: +req.query.page || 1,
		// limit: +req.query.limit || 10,
		sort: { createdAt: -1 },
	};

	let query = {};
	if (req.query.status) query.status = +req.query.status;
	if (req.query.category) query.category = +req.query.category;

	Order.find(query, null, options, (err, orders) => {
		if (err) return next(new BadRequestResponse(err));
		if (!orders) return next(new OkResponse([]));

		if (req.query.searchUser && !req.query.searchTailor)
			orders = orders.filter((order) => order.user.name.toLowerCase().includes(req.query.searchUser.toLowerCase()));
		else if (req.query.searchTailor && !req.query.searchUser)
			orders = orders.filter((order) => order.tailor.name.toLowerCase().includes(req.query.searchTailor.toLowerCase()));
		else if (req.query.searchUser && req.query.searchTailor)
			orders = orders.filter(
				(order) =>
					order.user.name.toLowerCase().includes(req.query.searchUser.toLowerCase()) &&
					order.tailor.name.toLowerCase().includes(req.query.searchTailor.toLowerCase())
			);

		console.log("orders", orders);
		return next(new OkResponse(orders));
	});
});

router.get("/get/complaints", auth.required, auth.admin, (req, res, next) => {
	const options = {
		// page: +req.query.page || 1,
		// limit: +req.query.limit || 10,
		sort: { createdAt: -1 },
	};

	let query = {};

	Complaint.find(query, null, options, (err, complaints) => {
		if (err) return next(new BadRequestResponse(err));
		if (!complaints) return next(new OkResponse([]));
		console.log("complaints", complaints);
		return next(new OkResponse(complaints));
	});
});

router.put("/change/status/:email", auth.required, auth.admin, (req, res, next) => {
	console.log("changeUserStatus", req.body);
	req.userToUpdate.status = +req.body.status;
	req.userToUpdate.save((err) => {
		if (err) return next(new BadRequestResponse(err));
		return next(new OkResponse("User status changed successfully"));
	});
});

module.exports = router;
