let router = require("express").Router();
let User = require("../../models/User");
let Order = require("../../models/Order");
let auth = require("../auth");
let { OkResponse, BadRequestResponse, UnauthorizedResponse } = require("express-http-response");

router.param("order", (req, res, next, slug) => {
	Order.findOne({ slug }, (err, order) => {
		if (err) return next(new BadRequestResponse(err));
		if (!order) return next(new BadRequestResponse("Order not Found"));
		req.order = order;
		next();
	});
});

// get user for every time mail given
router.param("email", (req, res, next, email) => {
	User.findOne({ email }, (err, user) => {
		if (!err && user !== null) {
			// console.log(user);
			req.userToUpdate = user;
			return next();
		}
		return next(new BadRequestResponse("User not found!", 423));
	});
});

router.post("/create/:email", auth.required, auth.user, (req, res, next) => {
	let { category, price, deliverDate, trialDate, instructions } = req.body;

	if (!category || !price || !deliverDate || !trialDate || !instructions)
		return next(new BadRequestResponse("Missing required fields"));

	let order = Order();

	order.category = category;
	order.price = price;
	order.deliverDate = deliverDate;
	order.trialDate = trialDate;
	order.instructions = instructions;

	order.isDelivered = req.body.isDelivered || false;
	order.isUrgent = req.body.isUrgent || false;
	order.isSampleGiven = req.body.isSampleGiven || false;
	order.sampleImages = req.body.images || [];

	order.user = req.user._id;
	order.tailor = req.userToUpdate._id;

	console.log(order);

	order.save((err, order) => {
		if (err) return next(new BadRequestResponse(err));
		return next(new OkResponse(order));
	});
});

router.get("/getAll", auth.required, auth.user, (req, res, next) => {
	console.log("---------req.body------------", req.body);

	const options = {
		// page: +req.query.page || 1,
		// limit: +req.query.limit || 10,
		sort: { createdAt: -1 },
	};

	let query = {};
	if (req.query.status) query.status = +req.query.status;
	if (req.query.category) query.category = +req.query.category;
	// if (req.query.search) query.search = req.query.search;

	if (+req.user.role === 2) query.tailor = req.user;
	else if (+req.user.role === 3) query.user = req.user;

	Order.find(query, null, options, (err, orders) => {
		if (err) return next(new BadRequestResponse(err));
		if (!orders) return next(new OkResponse([]));

		if (req.query.search) {
			if (+req.user.role === 3)
				orders = orders.filter((order) => order.tailor.name.toLowerCase().includes(req.query.search.toLowerCase()));
			else if (req.user.role === 2)
				orders = orders.filter((order) => order.user.name.toLowerCase().includes(req.query.search.toLowerCase()));
		}

		console.log("ORDERSSS", orders);
		return next(new OkResponse(orders));
	});
});

router.get("/get/clients", auth.required, auth.tailor, (req, res, next) => {
	// console.log("ISIS---------------------", req.body);

	const options = {
		// page: +req.query.page || 1,
		// limit: +req.query.limit || 10,
		sort: { createdAt: -1 },
	};

	let query = {};
	if (req.query.status) query.status = +req.query.status;

	query.tailor = req.user;

	Order.find(query, null, options, (err, orders) => {
		if (err) return next(new BadRequestResponse(err));
		if (!orders) return next(new OkResponse([]));
		console.log("ORDERSSS", orders);
		let clients = [];
		let clientSet = new Set();
		orders.forEach((order) => {
			clientSet.add(order.user);
		});
		clients = [...clientSet];

		if (req.query.search) {
			clients = clients.filter((client) => client.name.toLowerCase().includes(req.query.search.toLowerCase()));
		}

		return next(new OkResponse(clients));
	});
});

// View Specific Order
router.get("/get/:order", auth.required, auth.user, (req, res, next) => {
	return next(new OkResponse(req.order));
});

router.put("/status/:order", auth.required, auth.user, (req, res, next) => {
	console.log("body", req.body);
	console.log(req.order);
	if (req.order.tailor._id.toString() === req.user._id.toString() && req.body.status === 2) {
		req.order.status = req.body.status;
		req.order.save((err, order) => {
			if (err) return next(new BadRequestResponse(err));
			// emitEvent(req.order.slug, {});
			return next(new OkResponse(order));
		});
	} else if (
		(req.order.tailor._id.toString() === req.user._id.toString() ||
			req.order.user._id.toString() === req.user._id.toString()) &&
		req.body.status === 3
	) {
		req.order.status = req.body.status;
		req.order.save((err, order) => {
			if (err) return next(new BadRequestResponse(err));
			// emitEvent(req.order.slug, {});
			return next(new OkResponse(order));
		});
	} else {
		return next(new BadRequestResponse("You are not allowed to update this order"));
	}
});

router.put("/edit/:order", auth.required, auth.user, (req, res, next) => {
	console.log("Request Body", req.body);
	// console.log("Order", req.order);
	if (req.order.user._id.toString() === req.user._id.toString() && req.order.status === 1) {
		req.order.category = req.body.category || req.order.category;
		req.order.price = req.body.price || req.order.price;
		req.order.deliverDate = req.body.deliverDate || req.order.deliverDate;
		req.order.trialDate = req.body.trialDate || req.order.trialDate;
		req.order.instructions = req.body.instructions || req.order.instructions;
		req.order.isDelivered = req.body.isDelivered || req.order.isDelivered;

		req.order.isUrgent = req.body.isUrgent || req.order.isUrgent;
		req.order.sampleImages = req.body.images || req.order.sampleImages;

		if (req.body.tailor) {
			User.findOne(req.body.tailor, (err, tailor) => {
				if (err) return next(new BadRequestResponse(err));
				req.order.tailor = tailor._id;
				req.order.save((err, order) => {
					if (err) return next(new BadRequestResponse(err));
					// emitEvent(req.order.slug, {});
					return next(new OkResponse(order));
				});
			});
		} else {
			req.order.save((err, order) => {
				if (err) return next(new BadRequestResponse(err));
				return next(new OkResponse(order));
			});
		}
	} else {
		return next(new BadRequestResponse("You are not allowed to update this order"));
	}
});



module.exports = router;
