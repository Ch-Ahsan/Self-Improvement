let mongoose = require("mongoose");
const mongoosePaginate = require("mongoose-paginate-v2");
const slug = require("slug");

let OrderSchema = new mongoose.Schema(
	{
		slug: { type: String, unique: true },
		category: { type: Number, default: 0, enum: [0, 1, 2, 3, 4, 5, 6, 7, 8] },
		price: { type: String, default: "0" },
		isDelivered: { type: Boolean, default: false },
		deliverDate: { type: String },
		trialDate: { type: String },
		type: { type: Number, default: 1 }, // 1-man 2-woman
		instructions: { type: String },
		isSampleGiven: { type: Boolean, default: false },
		isUrgent: { type: Boolean, default: false },
		sampleImages: [{ type: String }],
		isAccepted: { type: Boolean, default: false },
		status: { type: Number, default: 1 }, //  1-placed  2-completed 3-cancelled
		user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
		tailor: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
	},
	{ timestamps: true }
);

OrderSchema.plugin(mongoosePaginate);

let autoPopulate = function (next) {
	//TODO
	this.populate("user");
	this.populate("tailor");
	next();
};

OrderSchema.pre("findOne", autoPopulate);
OrderSchema.pre("find", autoPopulate);
OrderSchema.pre("findById", autoPopulate);

OrderSchema.pre("validate", function (next) {
	if (!this.slug) {
		this.slugify();
	}
	next();
});

OrderSchema.methods.slugify = function () {
	this.slug = slug(((Math.random() * Math.pow(36, 6)) | 0).toString(36));
};

OrderSchema.methods.toJSON = function () {
	return {
		slug: this.slug,
		category: this.category,
		isDelivered: this.isDelivered,
		type: this.type,
		instructions: this.instructions,
		isSampleGiven: this.isSampleGiven,
		price: this.price,
		deliverDate: this.deliverDate,
		isUrgent: this.isUrgent,
		trialDate: this.trialDate,
		sampleImages: this.sampleImages,
		isAccepted: this.isAccepted,
		status: this.status,
		user: this.user,
		tailor: this.tailor,
	};
};

module.exports = mongoose.model("Order", OrderSchema);
