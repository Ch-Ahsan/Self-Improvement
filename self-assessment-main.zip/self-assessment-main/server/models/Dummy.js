let mongoose = require("mongoose");
const mongoosePaginate = require("mongoose-paginate-v2");
const slug = require("slug");

let DummySchema = new mongoose.Schema(
	{
		slug: { type: String, unique: true },
		email: String,
		name: String,
		age: Number,
		createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
	},
	{ timestamps: true }
);

DummySchema.plugin(mongoosePaginate);

let autoPopulate = function (next) {
	//TODO
	// this.populate("order");
	next();
};

DummySchema.pre("findOne", autoPopulate);
DummySchema.pre("find", autoPopulate);
DummySchema.pre("findById", autoPopulate);

DummySchema.pre("validate", function (next) {
	if (!this.slug) {
		this.slugify();
	}
	next();
});

DummySchema.methods.slugify = function () {
	this.slug = slug(((Math.random() * Math.pow(36, 6)) | 0).toString(36));
};

DummySchema.methods.toJSON = function () {
	return {
		slug: this.slug,
		email: this.email,
		name: this.name,
		age: this.age,
		createdBy: this.createdBy,
	};
};

module.exports = mongoose.model("Dummy", DummySchema);
