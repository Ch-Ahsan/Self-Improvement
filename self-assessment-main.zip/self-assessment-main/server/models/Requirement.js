let mongoose = require("mongoose");
const mongoosePaginate = require("mongoose-paginate-v2");
const slug = require("slug");

let requirementSchema = new mongoose.Schema(
	{
		slug: { type: String, unique: true },
		length: String,
		shoulder: String,
		upperChest: String,
		bust: String,
		waist: String,
		seat: String,
		armHole: String,
		sleeve: String,
		sleeveCircum: String,
		frontNeck: String,
		backNeck: String,
		bottomLength: String,
		bottomWaist: String,
		bottomHips: String,
		calf: String,
		chest: String,
		bottomBell: String,
		ply: String,
		pocket: String,
		pocketType: String,
		ankle: String,
		neck: String,
		collarType: String,
		knee: String,
		order: { type: mongoose.Schema.Types.ObjectId, ref: "Order" },
	},
	{ timestamps: true }
);

requirementSchema.plugin(mongoosePaginate);

let autoPopulate = function (next) {
	//TODO
	this.populate("order");
	next();
};

requirementSchema.pre("findOne", autoPopulate);
requirementSchema.pre("find", autoPopulate);
requirementSchema.pre("findById", autoPopulate);

requirementSchema.pre("validate", function (next) {
	if (!this.slug) {
		this.slugify();
	}
	next();
});

requirementSchema.methods.slugify = function () {
	this.slug = slug(((Math.random() * Math.pow(36, 6)) | 0).toString(36));
};

requirementSchema.methods.toJSON = function () {
	return {
		slug: this.slug,
		length: this.length,
		shoulder: this.shoulder,
		upperChest: this.upperChest,
		bust: this.bust,
		waist: this.waist,
		seat: this.seat,
		armHole: this.armHole,
		sleeve: this.sleeve,
		sleeveCircum: this.sleeveCircum,
		frontNeck: this.frontNeck,
		backNeck: this.backNeck,
		bottomLength: this.bottomLength,
		bottomWaist: this.bottomWaist,
		bottomHips: this.bottomHips,
		calf: this.calf,
		chest: this.chest,
		bottomBell: this.bottomBell,
		ply: this.ply,
		pocket: this.pocket,
		pocketType: this.pocketType,
		ankle: this.ankle,
		neck: this.neck,
		collarType: this.collarType,
		knee: this.knee,
		order: this.order,
	};
};

module.exports = mongoose.model("Requirement", requirementSchema);
