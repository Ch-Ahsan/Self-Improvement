let mongoose = require("mongoose");
const mongoosePaginate = require("mongoose-paginate-v2");
const slug = require("slug");

let complaintSchema = new mongoose.Schema(
	{
		slug: { type: String, unique: true },
		against: String,
		subject: String,
		message: String,
		by: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
	},
	{ timestamps: true }
);

complaintSchema.plugin(mongoosePaginate);

let autoPopulate = function (next) {
	this.populate("by");
	next();
};

complaintSchema.pre("findOne", autoPopulate);
complaintSchema.pre("find", autoPopulate);
complaintSchema.pre("findById", autoPopulate);

complaintSchema.pre("validate", function (next) {
	if (!this.slug) {
		this.slugify();
	}
	next();
});

complaintSchema.methods.slugify = function () {
	this.slug = slug(((Math.random() * Math.pow(36, 6)) | 0).toString(36));
};

complaintSchema.methods.toJSON = function () {
	return {
		slug: this.slug,
		against: this.against,
		subject: this.subject,
		message: this.message,
		by: this.by,
	};
};

module.exports = mongoose.model("Complaint", complaintSchema);
