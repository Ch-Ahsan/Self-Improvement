const User = require("../models/User");
const backend = require("../config").backend;

async function seedUser() {
	// Seed Admin
	{
		let newUser = new User();
		newUser.role = 1;

		newUser.email = "admin@gmail.com";
		newUser.name = "admin";

		newUser.setPassword("1234");
		newUser.isEmailVerified = true;

		await newUser.save();
	}
	// Seed user
	{
		let newUser = new User();

		newUser.email = "user@gmail.com";
		newUser.name = "user";
		newUser.address = "Ayub Park Saleem Colony";
		newUser.phone = "1234567890";
		newUser.dob = "01/01/2000";
		newUser.profileImage = `${backend}/uploads/noImage.png`;
		newUser.city = "Karachi";
		newUser.country = "Pakistan";
		newUser.postalCode = "52250";

		newUser.setPassword("1234");
		newUser.isEmailVerified = true;

		await newUser.save();
	}

	console.log("Default Users Seeded");
}

module.exports = seedUser;
